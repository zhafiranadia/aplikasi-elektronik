<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Toko Elektronik Nadia - Premium Electronics Store</title>
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH"
      crossorigin="anonymous"
    />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" />
    <style>
      .navbar-custom {
        background: linear-gradient(135deg, #6366f1, #4f46e5);
      }
      .hero-section {
        background: linear-gradient(135deg, #f3f4f6, #e5e7eb);
        border-radius: 15px;
        box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1);
      }
      .card {
        transition: transform 0.3s ease-in-out;
        border: none;
        box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1);
      }
      .card:hover {
        transform: translateY(-5px);
      }
      .card-img-top {
        height: 200px;
        object-fit: cover;
      }
      .price-tag {
        color: #4f46e5;
        font-weight: bold;
        font-size: 1.2rem;
      }
      .footer {
        background: linear-gradient(135deg, #6366f1, #4f46e5);
        color: white;
      }
      .search-form {
        background: white;
        padding: 2rem;
        border-radius: 10px;
        box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1);
      }
      .cart-btn {
        transition: all 0.3s ease;
      }
      .cart-btn:hover {
        transform: scale(1.05);
      }
    </style>
  </head>
  <body>
    <nav class="navbar navbar-expand-lg navbar-dark navbar-custom mb-4">
      <div class="container">
        <a class="navbar-brand" href="#">
          <i class="fas fa-tv me-2"></i>
          Toko Elektronik Nadia
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ms-auto">
            <li class="nav-item">
              <a class="nav-link" href="#"><i class="fas fa-home me-1"></i> Home</a>
            </li>
            <li class="nav-item">
              <button class="btn btn-secondary" data-bs-toggle="modal" data-bs-target="#loginModal">
                <i class="fas fa-sign-in-alt me-1"></i> Login
              </button>
            </li>
            <li class="nav-item ms-2">
              <a href="<?= base_url() ?>auth/logout" class="btn btn-danger">
                <i class="fas fa-sign-out-alt me-1"></i> Logout
              </a>
            </li>
            <li class="nav-item">
              <a href="<?= base_url() ?>chart" class="nav-link cart-btn">
                <i class="fas fa-shopping-cart me-1"></i>
                Cart <span class="badge bg-warning">4</span>
              </a>
            </li>
          </ul>
        </div>
      </div>
    </nav>

    <div class="container">
      <div class="row hero-section mb-5">
        <div class="col-md-6 p-5">
          <h1 class="display-4 fw-bold mb-3">Selamat Datang di Toko Elektronik Nadia</h1>
          <p class="lead mb-4">Temukan berbagai produk elektronik berkualitas dengan harga terbaik.</p>
          <a href="#products" class="btn btn-primary btn-lg">
            <i class="fas fa-shopping-bag me-2"></i>Lihat Produk
          </a>
        </div>
        <div class="col-md-6 p-5">
          <div class="search-form">
            <h2 class="h4 mb-4"><i class="fas fa-search me-2"></i>Cari Produk Elektronik</h2>
            <form action="">
              <div class="mb-3">
                <div class="input-group">
                  <span class="input-group-text"><i class="fas fa-laptop"></i></span>
                  <input type="text" class="form-control" placeholder="Jenis (e.g., Laptop, TV)" />
                </div>
              </div>
              <button class="btn btn-primary w-100">
                <i class="fas fa-search me-2"></i>Cari
              </button>
            </form>
          </div>
        </div>
      </div>

      <h2 class="h3 mb-4" id="products">
        <i class="fas fa-fire me-2"></i>Produk Unggulan
      </h2>
      <div class="row g-4 mb-5">
        <div class="col-md-3">
          <div class="card h-100">
            <img src="images/gambar 3.jpeg" class="card-img-top" alt="Laptop Asus" />
            <div class="card-body">
              <h5 class="card-title">Laptop Asus</h5>
              <p class="price-tag mb-3">Rp 7.000.000,-</p>
              <div class="d-flex justify-content-between align-items-center">
                <a href="<?= base_url() ?>chart" class="btn btn-primary">
                  <i class="fas fa-cart-plus me-2"></i>Tambah ke Keranjang
                </a>
              </div>
            </div>
          </div>
        </div>

        <div class="col-md-3">
          <div class="card h-100">
            <img src="images/gambar 2.jpg" class="card-img-top" alt="Smart TV Samsung" />
            <div class="card-body">
              <h5 class="card-title">Smart TV Samsung</h5>
              <p class="price-tag mb-3">Rp 5.000.000,-</p>
              <div class="d-flex justify-content-between align-items-center">
                <a href="<?= base_url() ?>chart" class="btn btn-primary">
                  <i class="fas fa-cart-plus me-2"></i>Tambah ke Keranjang
                </a>
              </div>
            </div>
          </div>
        </div>

        <div class="col-md-3">
          <div class="card h-100">
            <img src="images/gambar 5.jpg" class="card-img-top" alt="Headphone Sony" />
            <div class="card-body">
              <h5 class="card-title">mesin cuci</h5>
              <p class="price-tag mb-3">Rp 1.500.000,-</p>
              <div class="d-flex justify-content-between align-items-center">
                <a href="<?= base_url() ?>chart" class="btn btn-primary">
                  <i class="fas fa-cart-plus me-2"></i>Tambah ke Keranjang
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <footer class="footer py-4">
      <div class="container">
        <div class="row">
          <div class="col-md-4">
            <h5><i class="fas fa-tv me-2"></i>Toko Elektronik Nadia</h5>
            <p>Partner terpercaya untuk kebutuhan elektronik Anda.</p>
          </div>
          <div class="col-md-4">
            <h5><i class="fas fa-map-marker-alt me-2"></i>Lokasi</h5>
            <p>Jl. Elektronik Raya No. 45<br>Jambi, Indonesia</p>
          </div>
        </div>
        <div class="text-center">
          <p>© 2024 Toko Elektronik Nadia. Hak Cipta Dilindungi.</p>
        </div>
      </div>
    </footer>

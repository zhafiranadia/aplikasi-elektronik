<?= $this->extend('admin/template'); ?>

<?= $this->section('main'); ?>

<h2 class="mb-5">Daftar Elektronik</h2>

<div class="mb-3">
    <a href="<?= base_url('admin/daftar-elektronik/tambah')?>" class="btn btn-primary">Tambah Elektronik</a>
</div>

<div class="mb-5">
    <table class="table table-stripped">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Nama Elektronik</th>
                <th scope="col">Merek</th>
                <th scope="col">Spesifikasi</th>
                <th scope="col">Tahun Rilis</th>
                <th scope="col">Gambar</th>
                <th scope="col">Harga</th>
                <th scope="col">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($elektroniks as $elektronik):?>
            <tr>
                <th scope="row"><?=$elektronik['id']?></th>
                <td><?= $elektronik['nama']?></td>
                <td><?= $elektronik['merek']?></td>
                <td><?= $elektronik['spesifikasi']?></td>
                <td><?= $elektronik['tahun_rilis']?></td>
                <td>
                    <img src="<?= base_url($elektronik['gambar'])?>" alt="" style="width: 150px; height: auto;">
                </td>
                <td><?= $elektronik['harga']?></td>
                <td>
                    <a href="<?= base_url('admin/daftar-elektronik/edit')?>/<?=$elektronik['id']?>" class="btn btn-success">Edit</a>
                    <a href="<?= base_url('admin/daftar-elektronik/hapus')?>/<?=$elektronik['id']?>" class="btn btn-danger">Hapus</a>
                </td>
            </tr>
            <?php endforeach?>
        </tbody>
    </table>
</div>

<?= $this->endSection();?>

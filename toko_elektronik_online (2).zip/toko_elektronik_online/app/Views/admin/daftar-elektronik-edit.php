<?= $this->extend('admin/template') ?>
<?= $this->section('main') ?>
<h2 class="mb-5">Edit Elektronik</h2>
<form action="<?= base_url('admin/daftar-elektronik/change') ?>" method="post" enctype="multipart/form-data">
<button type="submit">Submit</button>
</form>
    <div class="mb-3">
        <label for="nama" class="form-label">Nama Elektronik</label>
        <input type="text" class="form-control w-50" id="nama"
            placeholder="nama" name="nama" value="<?= $elektronik['nama']; ?>"
            autocomplete="off" required>
    </div>
    <div class="mb-3">
        <label for="merek" class="form-label">Merek</label>
        <input type="text" class="form-control" id="merek" name="merek" value="<?= $elektronik['merek']; ?>"
            autocomplete="off" required>
    </div>
    <div class="mb-3">
        <label for="spesifikasi" class="form-label">Spesifikasi</label>
        <textarea class="form-control" id="spesifikasi" name="spesifikasi" 
            autocomplete="off" required><?= $elektronik['spesifikasi']; ?></textarea>
    </div>
    <div class="mb-3">
        <label for="tahun_rilis" class="form-label">Tahun Rilis</label>
        <input type="number" class="form-control" id="tahun_rilis" name="tahun_rilis" value="<?= $elektronik['tahun_rilis']; ?>"
            autocomplete="off" required>
    </div>
    <div class="mb-3">
        <label for="gambar" class="form-label">Gambar Elektronik</label>
        <input type="file" class="form-control" id="gambar" name="gambar" autocomplete="off">
        <small>Gambar saat ini: <?= $elektronik['gambar']; ?></small>
    </div>
    <div class="mb-3">
        <label for="harga" class="form-label">Harga</label>
        <input type="number" class="form-control" id="harga" name="harga" value="<?= $elektronik['harga']; ?>"
            autocomplete="off" required>
    </div>
    <div class="mb-3">
        <button type="submit" class="btn btn-primary">Ubah</button>
    </div>
</form>
<?= $this->endSection() ?>

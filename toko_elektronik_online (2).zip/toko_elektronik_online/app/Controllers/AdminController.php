<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\ElektronikModel;  // Ganti model dengan ElektronikModel
use CodeIgniter\HTTP\ResponseInterface;

class AdminController extends BaseController 
{
    public function index() 
    {
        return view('admin/dashboard');
    }

    // Daftar Elektronik
    public function daftarElektronik() 
    {
        $elektronikModel = new ElektronikModel(); // Ganti model dengan ElektronikModel
        $data['elektroniks'] = $elektronikModel->findAll();
        return view('admin/daftar-elektronik', $data);  // Ganti view dengan daftar-elektronik
    }

    public function daftarElektronikTambah() 
    {
        return view('admin/daftar-elektronik-tambah');  // Ganti view dengan daftar-elektronik-tambah
    }

    public function createElektronik() 
    {
        $data = $this->request->getPost();
        $file = $this->request->getFile('gambar');

        if(!$file->hasMoved()) {
            $path = $file->store('images');
            $data['gambar'] = $path;
        }

        $elektronikModel = new ElektronikModel();  // Ganti model dengan ElektronikModel

        if($elektronikModel->insert($data, false)) {
            return redirect()->to('admin/daftar-elektronik')->with('berhasil', 'Data Elektronik berhasil disimpan!');
        } else {
            return redirect()->to('admin/daftar-elektronik')->with('gagal', 'Data Elektronik gagal disimpan!');
        }
    }

    // Edit Elektronik
    public function daftarElektronikEdit($id) 
    {
        $elektronikModel = new ElektronikModel();  // Ganti model dengan ElektronikModel
        $data['elektronik'] = $elektronikModel->find($id);

        if ($data['elektronik']) {
            return view('admin/daftar-elektronik-edit', $data);  // Ganti view dengan daftar-elektronik-edit
        }
        return redirect()->to('admin/daftar-elektronik')->with('gagal', 'Data Elektronik tidak ditemukan.');
    }

    public function updateElektronik($id) 
    {
        $elektronikModel = new ElektronikModel();  // Ganti model dengan ElektronikModel
        $data = $this->request->getPost();
        
        // Handle image upload if new image is provided
        $file = $this->request->getFile('gambar');
        if ($file->isValid() && !$file->hasMoved()) {
            $path = $file->store('images');
            $data['gambar'] = $path;
        }

        if ($elektronikModel->update($id, $data)) {
            return redirect()->to('admin/daftar-elektronik')->with('berhasil', 'Data Elektronik berhasil diupdate!');
        }
        return redirect()->to('admin/daftar-elektronik')->with('gagal', 'Data Elektronik gagal diupdate!');
    }

    // Update Elektronik
    public function daftarElektronikUpdate($id) 
    {
        $elektronikModel = new ElektronikModel();  // Ganti model dengan ElektronikModel
        $data = $this->request->getPost();
        
        // Handle image upload if new image is provided
        $file = $this->request->getFile('gambar');
        if ($file->isValid() && !$file->hasMoved()) {
            $path = $file->store('images');
            $data['gambar'] = $path;
        }

        if ($elektronikModel->update($id, $data)) {
            return redirect()->to('admin/daftar-elektronik')->with('berhasil', 'Data Elektronik berhasil diupdate!');
        }
        return redirect()->to('admin/daftar-elektronik')->with('gagal', 'Data Elektronik gagal diupdate!');
    }

    // Hapus Elektronik
    public function hapusElektronik($id) 
    {
        $elektronikModel = new ElektronikModel();  // Ganti model dengan ElektronikModel
        $elektronik = $elektronikModel->find($id);

        if ($elektronik) {
            $elektronikModel->delete($id);
            return redirect()->to('/admin/daftar-elektronik')->with('berhasil', 'Data Elektronik berhasil dihapus.');
        }
        return redirect()->to('/admin/daftar-elektronik')->with('gagal', 'Data Elektronik tidak ditemukan.');
    }

    // Transaksi routes
    public function transaksi() 
    {
        return view('admin/transaksi');
    }

    public function transaksiUbahStatus() 
    {
        return view('admin/transaksi-ubah-status');
    }

    public function transaksiHapus() 
    {
        return view('admin/transaksi-hapus');
    }

    // Pelanggan routes
    public function pelanggan() 
    {
        return view('admin/pelanggan');
    }

    public function pelangganHapus() 
    {
        return view('admin/pelanggan-hapus');
    }
}

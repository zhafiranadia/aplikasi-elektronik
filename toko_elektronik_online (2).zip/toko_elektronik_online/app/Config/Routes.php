<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->get('/chart', 'Home::chart');
$routes->get('/checkout', 'Home::checkout');

$routes->post('/submit', 'Home::submit');

$routes->get('images/(:segment)', 'Home::image/$1');

$routes->group('admin', ['filter' => ['group:admin']], function($routes){
    $routes->get('', 'AdminController::index');
    $routes->get('dashboard', 'AdminController::index');
    
    // Daftar Elektronik routes
    $routes->get('daftar-elektronik', 'AdminController::daftarElektronik');
    $routes->get('daftar-elektronik/tambah', 'AdminController::daftarElektronikTambah');
    $routes->post('daftar-elektronik/tambah', 'AdminController::createElektronik');
    $routes->get('daftar-elektronik/edit/(:num)', 'AdminController::daftarElektronikEdit/$1');
    $routes->post('daftar-elektronik/update/(:num)', 'AdminController::daftarElektronikUpdate/$1'); // Ditambahkan route untuk update
    $routes->get('admin/daftar-elektronik/edit/(:num)', 'Admin\DaftarElektronik::edit/$1');
    $routes->post('admin/daftar-elektronik/change', 'Admin\DaftarElektronik::change');
    $routes->post('daftar-elektronik/edit', 'AdminController::daftarElektronikEdit');
    $routes->get('daftar-elektronik/hapus', 'AdminController::daftarElektronikHapus');
    
    $routes->get('daftar-elektronik/hapus/(:num)', 'AdminController::hapusElektronik/$1');
    $routes->get('admin/daftar-elektronik/hapus/(:num)', 'AdminController::hapusElektronik/$1');
    $routes->post('admin/daftar-elektronik/hapus/(:num)', 'AdminController::hapusElektronik/$1');
    
    // Transaksi routes
    $routes->get('transaksi', 'AdminController::transaksi');
    $routes->get('transaksi/ubah-status', 'AdminController::transaksiUbahStatus');
    $routes->get('transaksi/hapus', 'AdminController::transaksiHapus');
    
    // Pelanggan routes
    $routes->get('pelanggan', 'AdminController::pelanggan');
    $routes->get('pelanggan/hapus', 'AdminController::pelangganHapus');
});

service('auth')->routes($routes);
